#include <stdio.h>
./.aout
1            test