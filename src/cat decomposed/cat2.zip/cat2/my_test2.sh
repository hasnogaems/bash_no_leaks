#!/bin/bash
diff -s <(cat -T debug_n.txt) <(./s21_cat -T debug_n.txt) 

